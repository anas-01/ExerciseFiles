# 
# Example file for retrieving data from the internet
# LinkedIn Learning Python course by Joe Marini
#

def main():
    pass # this is a placeholder, do-nothing statement

if __name__ == "__main__":
    main()
